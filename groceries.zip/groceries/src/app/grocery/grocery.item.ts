export class GroceryItem {
  name: string;
  quantity: number;
  price: number;
  totalCost: number;

  constructor(name: string, quantity: number, price: number) {
    this.name = name;
    this.quantity = quantity;
    this.price = price;
    this.totalCost = quantity * price;
  }

  /**
   * Formats the totalCost variable for the purposes of display
   * @param locale - 'en-US'
   * @param style - 'currency'
   * @param currency - 'USD'
   */
  public formatTotalCost(locale: string, style: string, currency: string) {
    let formatter = new Intl.NumberFormat(locale, {
      style: style,
      currency: currency,
    });
    return formatter.format(this.totalCost);
  }
}
