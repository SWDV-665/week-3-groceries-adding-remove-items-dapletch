import {Component} from '@angular/core';
import {AlertController, ToastController} from '@ionic/angular';
import {GroceryItem} from "../grocery/grocery.item";

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  public groceries: Array<GroceryItem> = [
    new GroceryItem('Eggs', 2, 3.99),
    new GroceryItem('Milk', 1, 5.00),
    new GroceryItem('Oranges', 6, 1.00),
    new GroceryItem('Bread Loaf', 1, 4.29),
    new GroceryItem('Chocolate Bar', 3, 1.99)
  ];

  constructor(public toastController: ToastController, public alertController: AlertController) {}

  async removeItem(item, index) {
    console.log("Removing Item - ", item, index);
    const toast = await this.toastController.create({
      message: 'Removing Item - ' + index + " ...",
      duration: 3000
    });
    toast.present();
    this.groceries.splice(index, 1);
  }

  addItem() {
    console.log("Adding Item");
    this.showAddItemPrompt();
  }

  async showAddItemPrompt() {
    const prompt = await this.alertController.create({
      header: 'Add Item',
      message: "Please enter item...",
      inputs: [
        {
          name: 'name',
          placeholder: 'Name'
        },
        {
          name: 'quantity',
          placeholder: 'Quantity'
        },
        {
          name: 'price',
          placeholder: 'Price'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: item => {
            console.log('Saved clicked', item);
            this.groceries.push(
              new GroceryItem(item.name, item.quantity, item.price)
            );
          }
        }
      ]
    });
    prompt.present();
  }
}
